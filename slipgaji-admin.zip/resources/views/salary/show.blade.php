@extends('layouts.app')

@section('content')
<main class="d-flex w-100">
    <div class="container d-flex flex-column">
        <h1 class="mt-3">Create</h1>
        <div class="row">
            <div class="col-12 d-table mt-3">
                <div class="d-table-cell align-middle">
                    <div class="card">
                        <div class="card-header">
                            <h4>Gajian</h4>
                        </div>
                        <div class="card-body">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection
